#!/usr/bin/env bash

tensorboard --logdir models/writer/ --port=6007