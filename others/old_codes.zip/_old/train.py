""" Train RASOR model """

import shutil
from torch import optim
import torch.nn as nn
from rasor_model import SquadModel
from torch.autograd import Variable
import torch
import numpy as np
from base.utils import set_up_logger
from reader import get_data
from tensorboardX import SummaryWriter


class Config(object):
    def __init__(self):
        self.name = "RaSoR"

        # File paths produced by setup.py
        self.word_emb_data_path_prefix = 'data/preprocessed_glove_with_unks.split'   # preprocessed word embedding data
        self.tokenized_trn_json_path = 'data/train-v1.1.tokenized.split.json'        # tokenized training set JSON
        self.tokenized_dev_json_path = 'data/dev-v1.1.tokenized.split.json'          # tokenized dev set JSON

        # Hyper-parameters
        self.max_ans_len = 30          # maximal answer length, answers of longer length are discarded
        self.emb_dim = 300             # dimension of word embeddings
        self.ff_dim = 100
        # self.batch_size = 40
        self.batch_size = 10           # [DS] decreased from 40 due to out of memory issue in GPU
        self.max_num_epochs = 50       # max number of epochs to train for
        self.num_layers = 2            # number of BiLSTM layers, where BiLSTM is applied
        self.hidden_dim = 100          # dimension of hidden state of each uni-directional LSTM
        self.vocab_size = 114885
        self.seed = np.random.random_integers(1e6, 1e9)
    
    def __repr__(self):
        ks = sorted(k for k in self.__dict__ if k not in ['name'])
        return '\n'.join('{:<30s}{:<s}'.format(k, str(self.__dict__[k])) for k in ks)


def _gpu_dataset(name, dataset, config):
    print("loading dataset:", name)

    if dataset:
        ds_vec = dataset.vectorized
        ctxs, ctx_masks, ctx_lens = _gpu_sequences(name + '_ctxs', ds_vec.ctxs, ds_vec.ctx_lens)
        qtns, qtn_masks, qtn_lens = _gpu_sequences(name + '_qtns', ds_vec.qtns, ds_vec.qtn_lens)
        qtn_ctx_idxs = torch.from_numpy(ds_vec.qtn_ctx_idxs)
        anss, ans_stts, ans_ends = _gpu_answers(name, ds_vec.anss, config.max_ans_len)
    else:
        ctxs = ctx_masks = qtns = qtn_masks = torch.zeros(1, 1)
        ctx_lens = qtn_lens = qtn_ctx_idxs = anss = ans_stts = ans_ends = torch.zeros(1)
    return ctxs, ctx_masks, ctx_lens, qtns, qtn_masks, qtn_lens, qtn_ctx_idxs, anss, ans_stts, ans_ends


def _gpu_sequences(name, seqs_val, lens):
    print("generating sequences:", name)
    assert seqs_val.dtype == lens.dtype == np.int32
    num_samples, max_seq_len = seqs_val.shape
    assert len(lens) == num_samples
    assert max(lens) == max_seq_len
    gpu_seqs = torch.from_numpy(seqs_val)
    seq_masks_val = np.zeros((num_samples, max_seq_len), dtype=np.int32)
    for i, sample_len in enumerate(lens):
        seq_masks_val[i, :sample_len] = 1
        assert np.all(seqs_val[i, :sample_len] > 0)
        assert np.all(seqs_val[i, sample_len:] == 0)
    gpu_seq_masks = torch.from_numpy(seq_masks_val)
    gpu_lens = torch.from_numpy(lens)
    return gpu_seqs, gpu_seq_masks, gpu_lens


def _np_ans_word_idxs_to_ans_idx(ans_start_word_idx, ans_end_word_idx, max_ans_len):
    # all arguments are concrete ints
    assert ans_end_word_idx - ans_start_word_idx + 1 <= max_ans_len
    return ans_start_word_idx * max_ans_len + (ans_end_word_idx - ans_start_word_idx)


def _tt_ans_idx_to_ans_word_idxs(ans_idx, max_ans_len):
    # ans_idx theano int32 variable (batch_size,)
    # max_ans_len concrete int
    ans_start_word_idx = ans_idx // max_ans_len
    ans_end_word_idx = ans_start_word_idx + ans_idx % max_ans_len
    return ans_start_word_idx, ans_end_word_idx


def _gpu_answers(name, anss, max_ans_len):
    assert anss.dtype == np.int32
    assert anss.shape[1] == 2
    anss_val = np.array([_np_ans_word_idxs_to_ans_idx(ans_stt, ans_end, max_ans_len) for \
                         ans_stt, ans_end in anss], dtype=np.int32)
    ans_stts_val = anss[:, 0]
    ans_ends_val = anss[:, 1]

    gpu_anss = torch.from_numpy(anss_val)
    gpu_ans_stts = torch.from_numpy(ans_stts_val)
    gpu_ans_ends = torch.from_numpy(ans_ends_val)
    return gpu_anss, gpu_ans_stts, gpu_ans_ends


config = Config()
base_filename = config.name + '_cfg' + str(0)
logger = set_up_logger('logs/' + base_filename + '.log')
title = '{}: {}'.format(__file__, config.name)
logger.info('START ' + title + '\n\n{}\n'.format(config))
data = get_data(config, train=True)
emb_val = data.word_emb_data.word_emb  # (voc size, emb_dim)
first_known_word = data.word_emb_data.first_known_word
assert config.emb_dim == emb_val.shape[1]
assert first_known_word > 0
emb_val[:first_known_word] = 0
emb = torch.from_numpy(emb_val)


# Load all the data, train and dev data
trn_ctxs, trn_ctx_masks, trn_ctx_lens, \
trn_qtns, trn_qtn_masks, trn_qtn_lens, trn_qtn_ctx_idxs, \
trn_anss, trn_ans_stts, trn_ans_ends \
    = _gpu_dataset('trn', data.trn, config)

dev_ctxs, dev_ctx_masks, dev_ctx_lens, \
dev_qtns, dev_qtn_masks, dev_qtn_lens, dev_qtn_ctx_idxs, \
dev_anss, dev_ans_stts, dev_ans_ends \
    = _gpu_dataset('dev', data.dev, config)


def print_param(model):
    for name, param in model.state_dict().items():
        print(name,)

    print('\n')
    for param in list(model.parameters()):
        print(param.data.size())


loss_function = nn.NLLLoss()
if torch.cuda.is_available():
    loss_function = loss_function.cuda(0)


def eval_dev(model, epochid):
    """ Evaluate the model against the dev dataset """

    # probably shuffle the sample each epoch
    np_rng = np.random.RandomState(config.seed // 2)
    dataset_ctxs = dev_ctxs.long()
    dataset_ctx_masks = dev_ctx_masks.long()
    dataset_ctx_lens = dev_ctx_lens.long()
    dataset_qtns = dev_qtns.long()
    dataset_qtn_masks = dev_qtn_masks.long()
    dataset_qtn_lens = dev_qtn_lens.long()
    dataset_qtn_ctx_idxs = dev_qtn_ctx_idxs.long()
    dataset_anss = dev_anss.long()
    dataset_ans_stts = dev_ans_stts.long()
    dataset_ans_ends = dev_ans_ends.long()

    if torch.cuda.is_available():
        dataset_ctxs = dataset_ctxs.long().cuda(0)
        dataset_ctx_masks = dataset_ctx_masks.long().cuda(0)
        dataset_ctx_lens = dataset_ctx_lens.long().cuda(0)
        dataset_qtns = dataset_qtns.long().cuda(0)
        dataset_qtn_masks = dataset_qtn_masks.long().cuda(0)
        dataset_qtn_lens = dataset_qtn_lens.long().cuda(0)
        dataset_qtn_ctx_idxs = dataset_qtn_ctx_idxs.long().cuda(0)
        dataset_anss = dataset_anss.long().cuda(0)
        dataset_ans_stts = dataset_ans_stts.long().cuda(0)
        dataset_ans_ends = dataset_ans_ends.long().cuda(0)

    losses = []
    accs = []
    num_all_samples = data.dev.vectorized.qtn_ans_inds.size
    valid_qtn_idxs = np.flatnonzero(data.dev.vectorized.qtn_ans_inds).astype(np.int32)
    # indices of questions which have a valid answer
    num_samples = valid_qtn_idxs.size    
    np_rng.shuffle(valid_qtn_idxs)
    ss = range(0, num_samples, config.batch_size)

    for batch_id, s in enumerate(ss, 1):

        batch_idxs = valid_qtn_idxs[s:min(s + config.batch_size, num_samples)]
        if batch_idxs.size != config.batch_size:
            # In the last iteration if the size of the vector is not as batch size
            # GRU and LSTM layer would fail, since hidden state is initialized with fixed batch_size
            # can be fixed by dyanmic hidden layer inits
            continue

        qtn_idxs = torch.from_numpy(batch_idxs).long()
        if torch.cuda.is_available():
            qtn_idxs = qtn_idxs.cuda(0)

        ctx_idxs = dataset_qtn_ctx_idxs[qtn_idxs].long()  # (batch_size,)

        if torch.cuda.is_available():
            ctx_idxs = ctx_idxs.cuda(0)

        p_lens = dataset_ctx_lens[ctx_idxs]  # (batch_size,)

        max_p_len = p_lens.max()
        p = dataset_ctxs[ctx_idxs][:, :max_p_len].transpose(0, 1)  # (max_p_len, batch_size)
        p_mask = dataset_ctx_masks[ctx_idxs][:, :max_p_len].transpose(0, 1).long()  # (max_p_len, batch_size)
        if torch.cuda.is_available():
            p_mask = p_mask.cuda(0)        

        q_lens = dataset_qtn_lens[qtn_idxs]  # (batch_size,)
        max_q_len = q_lens.max()
        q = dataset_qtns[qtn_idxs][:, :max_q_len].transpose(0, 1)  # (max_q_len, batch_size)
        q_mask = dataset_qtn_masks[qtn_idxs][:, :max_q_len].transpose(0, 1).long()  # (max_q_len, batch_size)
        if torch.cuda.is_available():
            q_mask = q_mask.cuda(0)

        a = Variable(dataset_anss[qtn_idxs])  # (batch_size,)
        
        model.hidden = model.init_hidden(config.num_layers, config.hidden_dim, config.batch_size)

        scores = model(config, Variable(p, requires_grad=False), Variable(p_mask, requires_grad=False),
                       Variable(p_lens, requires_grad=False), Variable(q, requires_grad=False),
                       Variable(q_mask, requires_grad=False), Variable(q_lens, requires_grad=False))

        loss = loss_function(scores, a)
        _, a_hats = torch.max(scores, 1)
        # a_hats = a_hats.squeeze(1)

        acc = torch.eq(a_hats, a).float().mean()
        
        losses.append(loss.item())
        accs.append(acc.item())
        
        # if batch_id % 20 == 0:
        #     logger.info("Dev loss: {} accuracy:{} epochID: {} batchID:{}".format(
        #         loss.data[0], acc.data[0], epochid, batch_id))

    dev_loss = np.average(losses)
    dev_acc = np.average(accs)
    return dev_loss, dev_acc


def train(model, epochid):
    """ Train one epoch"""

    # indices of questions which have a valid answer
    valid_qtn_idxs = np.flatnonzero(data.trn.vectorized.qtn_ans_inds).astype(np.int32)
    num_samples = valid_qtn_idxs.size
    # probably shuffle the sample each epoch
    np_rng = np.random.RandomState(config.seed // 2)

    dataset_ctxs = trn_ctxs.long()
    dataset_ctx_masks = trn_ctx_masks.long()
    dataset_ctx_lens = trn_ctx_lens.long()
    dataset_qtns = trn_qtns.long()
    dataset_qtn_masks = trn_qtn_masks.long()
    dataset_qtn_lens = trn_qtn_lens.long()
    dataset_qtn_ctx_idxs = trn_qtn_ctx_idxs.long()
    dataset_anss = trn_anss.long()
    dataset_ans_stts = trn_ans_stts.long()
    dataset_ans_ends = trn_ans_ends.long()

    if torch.cuda.is_available():
        dataset_ctxs = dataset_ctxs.long().cuda(0)
        dataset_ctx_masks = dataset_ctx_masks.long().cuda(0)
        dataset_ctx_lens = dataset_ctx_lens.long().cuda(0)
        dataset_qtns = dataset_qtns.long().cuda(0)
        dataset_qtn_masks = dataset_qtn_masks.long().cuda(0)
        dataset_qtn_lens = dataset_qtn_lens.long().cuda(0)
        dataset_qtn_ctx_idxs = dataset_qtn_ctx_idxs.long().cuda(0)
        dataset_anss = dataset_anss.long().cuda(0)
        dataset_ans_stts = dataset_ans_stts.long().cuda(0)
        dataset_ans_ends = dataset_ans_ends.long().cuda(0)

    losses = []
    accs = []
    
    lr = 0.001    
    if epochid % 10 == 0:
        # Implement a learning rate decay
        lr = lr * 0.95

    np_rng.shuffle(valid_qtn_idxs)
    parameters = filter(lambda p: p.requires_grad, model.parameters())
    optimizer = optim.Adam(parameters, lr)
    ss = range(0, num_samples, config.batch_size)

    print("total num. of batches: ", len(ss))
    for batch_id, sample_id in enumerate(ss, 1):
        batch_idxs = valid_qtn_idxs[sample_id:min(sample_id + config.batch_size, num_samples)]
        if batch_idxs.size != config.batch_size:
            # in the last iteration if the size of the vector is not as batch size
            # GRU and LSTM layer would fail, since hidden state is initialized with fixed batch_size
            # can be fixed by dyanmic hidden layer inits
            continue

        qtn_idxs = torch.from_numpy(batch_idxs).long()
        if torch.cuda.is_available():
            qtn_idxs = qtn_idxs.cuda(0)

        ctx_idxs = dataset_qtn_ctx_idxs[qtn_idxs].long()  # (batch_size,)

        if torch.cuda.is_available():
            ctx_idxs = ctx_idxs.cuda(0)

        p_lens = dataset_ctx_lens[ctx_idxs]  # (batch_size,)

        max_p_len = p_lens.max()
        p = dataset_ctxs[ctx_idxs][:, :max_p_len].transpose(0, 1)  # (max_p_len, batch_size)
        p_mask = dataset_ctx_masks[ctx_idxs][:, :max_p_len].transpose(0, 1).long()  # (max_p_len, batch_size)
        if torch.cuda.is_available():
            p_mask = p_mask.cuda(0)        

        q_lens = dataset_qtn_lens[qtn_idxs]  # (batch_size,)
        max_q_len = q_lens.max()
        q = dataset_qtns[qtn_idxs][:, :max_q_len].transpose(0, 1)  # (max_q_len, batch_size)
        q_mask = dataset_qtn_masks[qtn_idxs][:, :max_q_len].transpose(0, 1).long()  # (max_q_len, batch_size)
        if torch.cuda.is_available():
            q_mask = q_mask.cuda(0)

        a = Variable(dataset_anss[qtn_idxs])  # (batch_size,)
        
        model.zero_grad()
        model.hidden = model.init_hidden(config.num_layers, config.hidden_dim, config.batch_size)
        model.hidden_qindp = model.init_hidden(config.num_layers, config.hidden_dim, config.batch_size)

        scores = model(config, Variable(p, requires_grad=False), Variable(p_mask, requires_grad=False),
                       Variable(p_lens, requires_grad=False), Variable(q, requires_grad=False),
                       Variable(q_mask, requires_grad=False), Variable(q_lens, requires_grad=False))

        loss = loss_function(scores, a)
        _, a_hats = torch.max(scores, 1)

        acc = torch.eq(a_hats, a).float().mean()
        
        loss.backward()
        optimizer.step()

        losses.append(loss.item())
        accs.append(acc.item())
        
        if batch_id % 30 == 0:
            logger.info("Train loss: {} accuracy:{} epochID: {} batchID:{}".format(
                loss.data[0], acc.data[0], epochid, batch_id))

    trn_loss = np.average(losses)
    trn_acc = np.average(accs)
    return trn_loss, trn_acc


def run():
    """ A main function """

    model = SquadModel(config, emb)
    if torch.cuda.is_available():
        model = model.cuda()

    # if os.path.isfile('./model_more_dropout.pth'):
    #     model.load_state_dict(torch.load('./model_more_dropout.pth'))

    max_acc = -np.inf
    max_acc_epoch = None

    shutil.rmtree('models/writer/')
    train_writer = SummaryWriter('models/writer/train')
    dev_writer = SummaryWriter('models/writer/dev')
    for epoch in range(1, config.max_num_epochs+1):
        trn_loss, trn_acc = train(model, epoch)
        dev_loss, dev_acc = eval_dev(model, epoch)

        logger.info("Epoch {:3d} Train loss:{:.6f} acc:{:.4f}, Dev loss:{:.6f} acc:{:.4f}".format(
            epoch, trn_loss, trn_acc, dev_loss, dev_acc))

        # logger.info("Train: After Epoch: {} avg. loss: {} avg. acc: {} ".format(epoch, trn_loss, trn_acc))
        # logger.info("Dev: After Epoch: {} avg. loss: {} avg. acc: {} ".format(epoch, dev_loss, dev_acc))

        train_writer.add_scalar('loss', trn_loss, epoch)
        train_writer.add_scalar('accuracy', trn_acc, epoch)
        dev_writer.add_scalar('loss', dev_loss, epoch)
        dev_writer.add_scalar('accuracy', dev_acc, epoch)

        if dev_acc > max_acc:
            logger.info("save file ... dev_acc:{:.6f}  epoch:{:3d}".format(dev_acc, epoch))
            torch.save(model.state_dict(), 'models/model_best_acc.pth')
            max_acc = dev_acc
            max_acc_epoch = epoch

    train_writer.close()
    dev_writer.close()

    with open('models/train_summary.txt', 'w') as fp:
        fp.write("best dev accuracy: {:.6f} at {}".format(max_acc, max_acc_epoch))


if __name__ == "__main__":
    run()
