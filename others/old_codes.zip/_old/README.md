# Learning Recurrent Span Representations for Extractive Question Answering

This repo implements *[Learning Recurrent Span Representations for Extractive Question Answering, ArXiv, 2017](https://arxiv.org/abs/1611.01436)*.
The codebase is based on [https://github.com/hsgodhia/squad_rasor_nn](https://github.com/hsgodhia/squad_rasor_nn) but the original repo has some bugs. This repo fixes the bugs, cleans the codes and run on Python 3. 


The paper authros' repository is [https://github.com/shimisalant/RaSoR](https://github.com/shimisalant/RaSoR) which is based on Theano. 



## Dependency
* Python 3.6
* PyTorch

## Preparation

```
$ python setup.py
```
This will download GloVe word embeddings and tokenize raw training / development data. 


## How to Train 
```
$ python train.py
```

## How to Predict

```
$ python predict.py
```

Not implemented yet

## Others
* `./run_tensorboard.sh` runs the tensorboard server. The port number is 6007. 